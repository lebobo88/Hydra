# Covenant

A small, statically checked language for **governed agent programs** — agents, tools,
rubrics, budgets and the rules they run under — that compiles to every agent runtime
(Claude Code, Copilot CLI, Codex, OpenCode, Pi, Antigravity CLI, Cursor, AGENTS.md) and runs flows on one durable,
budget-enforcing engine.

<a href="docs/media/covenant-film.mp4"><img src="docs/media/covenant-film-poster.jpg" alt="Covenant: Write it once. Enforce it everywhere. Click to watch the film." width="720"></a>

*Watch the film (1:40): what Covenant is and why it exists.*

```
agent AgentsMdAuthor under PairProgrammer {
  describe "Keeps AGENTS.md in sync with PROJECT_MASTER.md sections 11-14."
  model    haiku
  uses     mcp.pp_harness.{ensure_agents_md, apply_agents_md_patch, agents_md_status},
           fs.read("{project_path}/PROJECT_MASTER.md")
  budget   { turns: 12, usd: 0.50 }
  ...
}
```

## Status

**M0 complete (2026-10-24):** research, language spec v0.2 (after a cold-write test and an
adversarial review), and an executable reference checker with 72 tests.
**2026-10-26:** spec v0.3 after a completeness pass for independent implementers; the
reference checker now has 182 tests. The compiler
itself is built next, task by task, by model-routed Claude Code sessions (ADR-011).

| Start here | |
| --- | --- |
| Why this exists, with data | `RLM/research/FINDINGS.md` |
| What v1 does | `RLM/specs/PRD.md` |
| The language | `RLM/specs/language/LANGUAGE.md` |
| How it's built | `RLM/specs/architecture/OVERVIEW.md`, `RLM/specs/architecture/decisions/` |
| When | `docs/ROADMAP.md` |
| How the build runs | `docs/IMPLEMENTATION-PLAN.md` |
| Rules for contributors and agents | `AGENTS.md`, `RLM/specs/constitution.md` |

## Try the reference checker

Python 3.12+, no dependencies:

```bash
cd examples
python3 -I ../RLM/specs/language/reference/covref.py *.cov
# ship-change.cov:74: warning W0302: flow ShipChange: cap usd 6.00 is below the
#   structural sum of child caps (8.20); the flow cap will bind first

python3 -I ../RLM/specs/language/reference/run_tests.py   # 182 tests, 0 failing
```

## Install `cov` in another repo

`cov` is released as a tarball, not through a registry. Build it from a clean checkout with the
tag on HEAD:

```bash
pnpm release -- v0.1.0 --out <dir>   # writes the .tgz and <tarball>.sha256 into <dir>
```

Commit the tarball in the consuming repo and depend on it by file path:

```json
"@lebobo88/covenant-cli": "file:<path to the .tgz>"
```

Then `npm install` and `npx cov --version`. The tarball is one bundled `bin.js` and depends on
`better-sqlite3` (the runtime's native addon), which `npm install` fetches at the version
`pnpm-lock.yaml` resolves; `cov run` also needs `@anthropic-ai/claude-agent-sdk` in the host's
`node_modules`. Anyone can check the committed tarball by rebuilding at the same tag and comparing
the sha256. No token and no `.npmrc` are needed. Without `--out` (or with `--dry-run`) the script
builds, packs and verifies the tarball and keeps nothing.

## Repository map

```
examples/                 canonical .cov programs
RLM/specs/                PRD, constitution, language, architecture, features (FTR-001…014)
RLM/tasks/active/         TASK-001…045, each sized for one session and PR
RLM/research/             findings, landscape, field mapping, cold-write test, review, data, scripts
docs/                     roadmap, implementation plan
```

Private. © Rob Lee Media.
